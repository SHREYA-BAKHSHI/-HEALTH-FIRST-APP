This REST Server aggregates the data from the social media websites.
