This is how the Mongo DB looks like.
