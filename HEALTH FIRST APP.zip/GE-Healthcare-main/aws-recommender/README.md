This is a reommendation engine wrapped in a Flask app and exposed as REST server.
